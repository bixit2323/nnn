criaCartao(
    'Primeira Pergunta',
    'Quem sou eu ?',
    'Meu nome é alifer tenho 15 anos estou em busca de realizar meu sonho',
)

criaCartao(
    'Segunda Pergunta',
    'minha familia é ?',
    'É uma familia muito unida e procura sempre entender o lado dos outros e quando possivél ajuda, é uma familia unida e responsável',
)

criaCartao(
    'Terceira Pergunta',
    'onde moro?',
    'Moro em pinhão paraná no bairro colina verde,25°42 37"S 51°38 22"',
)

criaCartao(
    'Quarta Pergunta',
    'Onde estudo?',
    'Estudo no colegio Mário Evaldo Morski',
)
criaCartao(
    'quinta Pergunta',
    'minha turma ?',
    'É uma turma bem inteligente as vezes aprontam bastante mas é bem unida',
)

criaCartao(
    'Sexta Pergunta',
    'faculdade ?',
    'Pretendo fazer agronomia',
)

criaCartao(
    'setima Pergunta',
    'Minha cidade?',
    'minha cidade é uma cidade bem bonita mas é uma cidade pequena',
)

criaCartao(
    'Oitava Pergunta',
    'meu sonho ?',
    'Meu sonho é passar na faculdade e seguir no ramo que sempre quis ter, e ter uma familia bem unida longe de todos os maleficios ',
)